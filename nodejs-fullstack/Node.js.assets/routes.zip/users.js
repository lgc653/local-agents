var express = require("express");
var router = express.Router();
var MongoClient = require("mongodb").MongoClient;
require("./MongoPool").initPool();

/* GET users listing. */
router.post("/:app_uuid", function(req, res, next) {
	//console.log(req.params);
	// 此处注意，此处有windows平台用localhost连接比127.0.0.1慢N倍的坑
	var url = "mongodb://adsadmin:adsadmin@127.0.0.1:27017/ads";
	MongoClient.connect(
		url,
		function(err, db) {
			if (err) throw err;
			var dbo = db.db("ads");
			var whereStr = { app_uuid: req.params.app_uuid };
			dbo.collection("app")
				.find(whereStr)
				.toArray(function(err, result) {
					// 返回集合中所有数据
					if (err) throw err;
					console.log(result);
					var whereStr = { app_uuid: req.params.app_uuid };
					const searcher = require("lionsoul-ip2region").create();
					const region = searcher.btreeSearchSync("27.18.165.1");
					console.dir(region);
					dbo.collection("ad")
						.find({ ad_type: "self" })
						.sort({ weight: -1 })
						.limit(4)
						.toArray(function(err, result) {
							// 返回集合中所有数据
							if (err) throw err;
							// console.log(result);
							res.json(result); //以json格式输出
							let timeUnix = Date.parse(new Date()) / 1000;
							dbo.collection("client").findAndModify(
								{ client_uuid: req.body.client_uuid }, // query
								[["_id", "asc"]], // sort order
								{ $set: { client_uuid: req.body.client_uuid, time: timeUnix } }, // replacement, replaces only the field "hi"
								{ new: true, upsert: true }, // options
								function(err, object) {
									if (err) {
										console.warn(err.message); // returns error if no matching object found
									} else {
										console.dir(object);
										db.close();
									}
								}
							);
						});
				});
		}
	);
});

router.post("/await/:app_uuid", function(req, res, next) {
	(async function() {
		// 此处注意，此处有windows平台用localhost连接比127.0.0.1慢N倍的坑
		var url = "mongodb://adsadmin:adsadmin@127.0.0.1:27017/ads";
		const db = await MongoClient.connect(url);
		let dbo = await db.db("ads");
		var whereStr = { app_uuid: req.params.app_uuid };
		let resultApp = await dbo
			.collection("ad")
			.find({ ad_type: "self" })
			.sort({ weight: -1 })
			.limit(4)
			.toArray();
		const searcher = require("lionsoul-ip2region").create();
		const region = searcher.btreeSearchSync("27.18.165.1");
		console.dir(region);
		let resultAds = await dbo
			.collection("ad")
			.find({ ad_type: "self" })
			.sort({ weight: -1 })
			.limit(4)
			.toArray();
		let timeUnix = Date.parse(new Date()) / 1000;
		let object = await dbo.collection("client").findAndModify(
			{ client_uuid: req.body.client_uuid }, // query
			[["_id", "asc"]], // sort order
			{ $set: { client_uuid: req.body.client_uuid, time: timeUnix } }, // replacement, replaces only the field "hi"
			{ new: true, upsert: true }
		);
		console.dir(object);
		await db.close();
		res.json(resultAds);
	})();
});

router.post("/pool/:app_uuid", function(req, res, next) {
	var MongoPool = require("./MongoPool");
	MongoPool.getInstance(
		function(db) {
			var dbo = db.db("ads");
			var whereStr = { app_uuid: req.params.app_uuid };
			dbo.collection("app")
				.find(whereStr)
				.toArray(function(err, result) {
					// 返回集合中所有数据
					if (err) throw err;
					console.log(result);
					var whereStr = { app_uuid: req.params.app_uuid };
					const searcher = require("lionsoul-ip2region").create();
					const region = searcher.btreeSearchSync("27.18.165.1");
					console.dir(region);
					dbo.collection("ad")
						.find({ ad_type: "self" })
						.sort({ weight: -1 })
						.limit(4)
						.toArray(function(err, result) {
							// 返回集合中所有数据
							if (err) throw err;
							// console.log(result);
							res.json(result); //以json格式输出
							let timeUnix = Date.parse(new Date()) / 1000;
							dbo.collection("client").findAndModify(
								{ client_uuid: req.body.client_uuid }, // query
								[["_id", "asc"]], // sort order
								{ $set: { client_uuid: req.body.client_uuid, time: timeUnix } }, // replacement, replaces only the field "hi"
								{ new: true, upsert: true }, // options
								function(err, object) {
									if (err) {
										console.warn(err.message); // returns error if no matching object found
									} else {
										console.dir(object);
										//db.close();
									}
								}
							);
						});
				});
		}
	);
});

module.exports = router;
